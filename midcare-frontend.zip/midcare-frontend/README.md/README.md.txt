# VidhyaMed - Emergency Healthcare Frontend

## Overview
Frontend prototype of emergency healthcare platform with real-time location tracking and patient dashboard.

## Features
- Emergency Button
- Patient Dashboard
- Real-Time Location Map
- Responsive Design

## Tech Stack
- HTML, CSS, JavaScript
- Leaflet.js
- GitHub Pages for deployment

## Live Demo
https://YOURUSERNAME.github.io/vidhya-med/